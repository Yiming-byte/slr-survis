var title = "Systematic Literature Review Tools";
var editable = false;